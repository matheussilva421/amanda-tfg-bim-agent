# Amanda TFG BIM Agent — Superpowers Plan Bundle

This bundle contains the approved design specification and the decomposed implementation plans required to build and operate the Codex/Revit system.

## Files

- `2026-09-11-amanda-tfg-bim-agent-design.md` — approved design specification.
- `00-master-implementation-plan.md` — orchestration, dependencies, global gates.
- `01-foundation-environment-state.md` — control plane, environment, snapshots, durable state.
- `02-revit-tool-lab-providers.md` — Horizun/RevitCortex/custom API proof, fault injection, capability matrix.
- `03-project-intelligence.md` — source intake, provenance, canonical program/site/regulations.
- `04-design-engine.md` — deterministic generative design, scoring, Pareto, optional environmental tools.
- `05-bim-compiler.md` — desired-state Revit stages R01–R13.
- `06-qa-release-exports.md` — R14–R16, persistence, export validation, GOLDEN.
- `07-autonomy-recovery-security.md` — session continuity, locks, recovery, security, maintenance.
- `08-amanda-production-run.md` — real project end-to-end execution after synthetic validation.
- `09-optional-render-cloud.md` — Blender rendering and APS fallback only after local stability.
- `START_HERE_FOR_CODEX.md` — ready-to-paste execution handoff.

## Execution order

`00 → 01 → 02 → (03 + 07 where independent) → 04 → 05 → 06 → 08 → 09 optional`

## Why separate plans?

The approved specification contains multiple independently testable subsystems. Superpowers `writing-plans` requires those units to be independently reviewable and executable. The master plan enforces their dependency order and GO/NO-GO gates.

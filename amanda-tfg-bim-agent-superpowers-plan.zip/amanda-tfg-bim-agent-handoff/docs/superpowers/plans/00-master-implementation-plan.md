# Amanda TFG BIM Agent — Master Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use `superpowers:subagent-driven-development` (recommended) or `superpowers:executing-plans` to implement this plan task-by-task. Use `superpowers:using-git-worktrees` at execution time when starting from an existing repository. Use TDD for code, systematic debugging for failures, and verification-before-completion before claiming any task/phase is complete.

**Goal:** Build a local-first, fault-tolerant Codex-controlled architecture/BIM pipeline that ingests Amanda's TFG sources, proves Revit integrations on this PC, generates architectural alternatives, compiles an approved alternative into Autodesk Revit 2027, validates it, and emits an immutable GOLDEN release.

**Architecture:** One orchestration plan plus independent child plans. Every child plan produces testable software/evidence and ends in a `GO`, `GO_WITH_LIMITATIONS`, or `NO_GO` gate. Revit production writes are forbidden until the Tool Lab has generated a verified Capability Registry.

**Tech Stack:** Windows, Autodesk Revit 2027 Education, Codex CLI, Git, PowerShell, Python 3.12 x64, pytest, Pydantic, Typer, OR-Tools, Shapely, NetworkX, IfcOpenShell; optional TopologicPy/Ladybug/Honeybee; .NET 10; Horizun Revit MCP; RevitCortex; optional Blender MCP and Autodesk APS fallback.

**Spec:** `docs/superpowers/specs/2026-09-11-amanda-tfg-bim-agent-design.md`

## Global Constraints

- Detect the exact installed Revit 2027 build; never assume it.
- Local-first. APS/cloud is last-resort fallback only.
- Maximum local autonomy; stop only for UAC, authentication/licensing, essential missing source data, final architectural selection, or irreversible external action.
- One active writer per RVT.
- Never write to files whose path identifies them as `GOLDEN`, `MASTER`, or source originals.
- Every BIM write follows `WRITE → READ → VERIFY`.
- A tool-returned success flag is not evidence of actual model mutation.
- No `UNTESTED` provider may touch Amanda production.
- Source facts, derived constraints, and design hypotheses are separate data classes.
- Requirements are immutable during optimization.
- Missing topography remains missing; do not fabricate elevations/declivities.
- Dependency/provider/Revit updates occur only in maintenance branches and require regression before promotion.
- Every task ends in `PASS`, `PASS_WITH_WARNINGS`, `DEGRADED`, `BLOCKED_BY_INPUT`, `BLOCKED_BY_TOOL`, `FAILED_ROLLED_BACK`, or `CRITICAL_FAILURE`.

## Current upstream contracts to re-check before installation

At execution time, Codex must re-open these upstream sources, record their current commit/release, then pin the exact commit used:

- Horizun Revit MCP: `https://github.com/HorizunGroup/horizun-revit-mcp`
  - Current source-build docs support Revit 2023–2027.
  - Current `AGENTS.md` requires exact .NET SDK `10.0.400` for the source build.
  - Current source install command: `powershell -ExecutionPolicy Bypass -File .\install.ps1`.
  - Current Codex registration uses the absolute installed executable path discovered after installation; the installation task computes that path and calls `codex mcp add horizun-revit -- $HorizunExe`.
- RevitCortex: `https://github.com/LuDattilo/RevitCortex`
  - Current docs support Revit 2023–2027.
  - Revit 2027 plugin build uses `Release R27` and .NET 10+.
- Autodesk Revit 2027 API docs: `https://help.autodesk.com/view/RVT/2027/ENU/?guid=f7165618-24c9-4160-a7a4-09979fe4a981`
  - Revit 2027 runs on .NET 10.
- Codex MCP docs: `https://developers.openai.com/codex/mcp`
  - `codex mcp add NAME -- COMMAND`
  - `codex mcp list`
  - `/mcp` in Codex TUI.
- OR-Tools: `https://developers.google.com/optimization/install`
- Shapely: `https://shapely.readthedocs.io/`
- IfcOpenShell: `https://docs.ifcopenshell.org/ifcopenshell-python/installation.html`
- TopologicPy: `https://github.com/wassimj/topologicpy`
- Ladybug/Honeybee: `https://github.com/ladybug-tools/ladybug`, `https://github.com/ladybug-tools/lbt-honeybee`
- APS samples: `https://github.com/autodesk-platform-services/aps-sample-mcp-server-revit-automation`, `https://github.com/autodesk-platform-services/aps-sample-revit-mcp-tools-bundle`
- Blender MCP optional: `https://github.com/ahujasid/blender-mcp`

---

## Plan Map

```text
00 MASTER
   |
   v
01 FOUNDATION / ENVIRONMENT / STATE
   |
   v
02 REVIT TOOL LAB / PROVIDERS
   |\
   | \
   v  v
03 PROJECT INTELLIGENCE        07 AUTONOMY / RECOVERY / SECURITY
   |                               |
   v                               |
04 DESIGN ENGINE                   |
   |                               |
   v                               |
05 BIM COMPILER <------------------+
   |
   v
06 QA / RELEASE / EXPORTS
   |
   v
08 AMANDA PRODUCTION RUN
   |
   v
09 OPTIONAL RENDER / CLOUD
```

## Child Plans

1. `01-foundation-environment-state.md`
2. `02-revit-tool-lab-providers.md`
3. `03-project-intelligence.md`
4. `04-design-engine.md`
5. `05-bim-compiler.md`
6. `06-qa-release-exports.md`
7. `07-autonomy-recovery-security.md`
8. `08-amanda-production-run.md`
9. `09-optional-render-cloud.md`

---

### Task M1: Initialize repository from the approved bundle

**Files:**
- Create: `docs/superpowers/specs/2026-09-11-amanda-tfg-bim-agent-design.md`
- Create: `docs/superpowers/plans/*.md`
- Create: `.gitignore`

**Interfaces:**
- Consumes: this bundle.
- Produces: the canonical Git repository.

- [ ] **Step 1: Create repository root**

```powershell
$RepoRoot = Join-Path (Get-Location) "amanda-tfg-bim-agent"
New-Item -ItemType Directory -Force -Path $RepoRoot | Out-Null
Set-Location $RepoRoot
git init
```

Expected: empty Git repository.

- [ ] **Step 2: Create documentation directories**

```powershell
New-Item -ItemType Directory -Force -Path "docs/superpowers/specs","docs/superpowers/plans" | Out-Null
```

- [ ] **Step 3: Copy the approved design spec and plan files from the supplied bundle**

After copying, verify:

```powershell
Get-ChildItem docs/superpowers/specs
Get-ChildItem docs/superpowers/plans
```

Expected: exactly one approved design spec plus master and nine child plans.

- [ ] **Step 4: Create `.gitignore`**

```gitignore
.venv/
.venv-*/
.tools/
__pycache__/
.pytest_cache/
.mypy_cache/
.ruff_cache/
.env
.env.*
!.env.example
logs/raw/
revit/lab/**/*.rvt
revit/production/working/*.rvt
bim/checkpoints/*.rvt
bim/releases/**/*.rvt
*.0001.rvt
*.0002.rvt
*.0003.rvt
*.slog
```

- [ ] **Step 5: Commit baseline**

```powershell
git add docs .gitignore
git commit -m "docs: add approved Amanda BIM design and implementation plans"
```

Expected: clean `git status`.

---

### Task M2: Enforce plan dependency order

**Files:**
- Modify later: `PROJECT_STATE.yaml`

**Interfaces:**
- Consumes: child phase gates.
- Produces: controlled phase advancement.

- [ ] Execute Plan 01. If `NO_GO`, stop.
- [ ] Execute Plan 02. If core Revit capabilities are not green, stop production work.
- [ ] Execute Plan 03 and Plan 07 after Plan 02; parallelize only independent files/tasks.
- [ ] Execute Plan 04 after canonical requirements/site schemas are stable.
- [ ] Execute Plan 05 only after at least one typed Revit provider plus a verified core fallback are in the Capability Registry.
- [ ] Execute Plan 06 and require cold save/close/restart/reopen verification.
- [ ] Execute Plan 08 only after all synthetic regression fixtures pass.
- [ ] Execute Plan 09 only after a local synthetic and/or Amanda GOLDEN path is stable.

---

### Task M3: Global completion verification

**Files:**
- Read: `state/status.md`, `PROJECT_STATE.yaml`, release manifest.

- [ ] **Step 1: Fast deterministic tests**

```powershell
.\.venv\Scripts\python.exe -m pytest tests/unit tests/geometry tests/solver -q
```

Expected: PASS.

- [ ] **Step 2: Full non-Revit regression**

```powershell
.\.venv\Scripts\python.exe -m pytest tests -m "not revit" -q
```

Expected: PASS.

- [ ] **Step 3: Doctor**

```powershell
.\.venv\Scripts\python.exe -m amanda_agent doctor
```

Expected: critical local systems PASS.

- [ ] **Step 4: Status**

```powershell
.\.venv\Scripts\python.exe -m amanda_agent status
```

Expected: no unexplained blocker/stale writer lease/dirty phase state.

- [ ] **Step 5: If GOLDEN exists, validate manifest and hashes**

```powershell
Get-Content bim/releases/GOLDEN-001/manifest.json | ConvertFrom-Json | Format-List
```

Expected: QA PASS, persistence PASS, export results, provider pins, source versions, and hashes.

---

## Master GO/NO-GO Policy

### GO
Proceed automatically.

### GO_WITH_LIMITATIONS
Proceed only if the limitation is in `state/blockers.yaml` and it does not invalidate the next phase. Example: missing verified topography may permit schematic design but blocks final grading.

### NO_GO
Preserve state, write a blocker report under `docs/reports/blockers/`, and stop dependent work.

---

## Execution Handoff

At implementation time:

1. read the design spec;
2. read this master plan;
3. read only the child plan for the current phase plus interfaces it consumes;
4. create/use an isolated worktree as Superpowers requires;
5. use TDD for each code task;
6. record evidence for each Revit tool task;
7. commit after every independently testable task;
8. update `PROJECT_STATE.yaml` after task completion;
9. never skip a phase gate because a downstream component “probably works”.

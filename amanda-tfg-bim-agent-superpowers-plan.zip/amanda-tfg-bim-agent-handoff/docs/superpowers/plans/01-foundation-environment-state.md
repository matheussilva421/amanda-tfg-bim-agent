# Foundation, Environment, Persistent State, and CLI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use `superpowers:subagent-driven-development` or `superpowers:executing-plans`. Use TDD for code, systematic debugging for failures, verification-before-completion before phase PASS.

**Goal:** Create the Python control plane, detect the real Windows/Revit/Codex/.NET environment, snapshot configurations, establish durable project state, single-writer locking, logs, and `doctor/status/resume/rollback` commands.

**Architecture:** A Python 3.12 package owns project state and deterministic policy. Environment probes are isolated so they can be unit tested. Bootstrap never edits Amanda RVTs.

**Tech Stack:** Python 3.12 x64, Typer, Pydantic v2, PyYAML, Rich, pytest, PowerShell, Git.

**Spec:** `docs/superpowers/specs/2026-09-11-amanda-tfg-bim-agent-design.md`

## Global Constraints

- Revit is already installed; do not reinstall it.
- Detect Revit by installed files/metadata.
- Plan 02 source-build of Horizun requires exact .NET SDK 10.0.400.
- Preserve existing Codex MCP config and Revit add-ins.
- Snapshot before modification.
- Never persist secrets to Git/logs.

---

## File Structure

```text
src/amanda_agent/
├── __init__.py
├── __main__.py
├── cli.py
├── paths.py
├── logging.py
├── models/
│   ├── environment.py
│   └── state.py
├── state/
│   ├── store.py
│   └── locks.py
├── bootstrap/
│   ├── revit.py
│   ├── environment.py
│   └── snapshots.py
└── commands/
    ├── doctor.py
    ├── status.py
    ├── resume.py
    └── rollback.py

tests/
├── unit/
└── bootstrap/
```

### Task 1: Bootstrap Python package and CLI

**Files:**
- Create: `pyproject.toml`
- Create: `src/amanda_agent/__init__.py`
- Create: `src/amanda_agent/__main__.py`
- Create: `src/amanda_agent/cli.py`
- Test: `tests/unit/test_cli.py`

**Interfaces:**
- Produces `python -m amanda_agent`.

- [ ] **Step 1: Write failing CLI test**

```python
from typer.testing import CliRunner
from amanda_agent.cli import app

runner = CliRunner()

def test_help_lists_core_commands():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for command in ("doctor", "status", "resume", "rollback"):
        assert command in result.stdout
```

- [ ] **Step 2: Create `pyproject.toml`**

```toml
[build-system]
requires = ["setuptools>=75"]
build-backend = "setuptools.build_meta"

[project]
name = "amanda-tfg-bim-agent"
version = "0.1.0"
requires-python = ">=3.12,<3.13"
dependencies = [
  "typer>=0.16,<1",
  "pydantic>=2.11,<3",
  "PyYAML>=6,<7",
  "rich>=14,<15"
]

[project.optional-dependencies]
dev = [
  "pytest>=8.4,<9",
  "pytest-cov>=6,<7",
  "ruff>=0.12,<1",
  "mypy>=1.17,<2"
]

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
testpaths = ["tests"]
markers = [
  "revit: requires running Revit and a verified provider",
  "slow: intentionally expensive"
]
```

- [ ] **Step 3: Create minimal CLI**

```python
# src/amanda_agent/cli.py
import typer

app = typer.Typer(no_args_is_help=True)

@app.command()
def doctor() -> None:
    typer.echo("doctor: bootstrap implementation pending")

@app.command()
def status() -> None:
    typer.echo("status: bootstrap implementation pending")

@app.command()
def resume() -> None:
    typer.echo("resume: bootstrap implementation pending")

@app.command()
def rollback() -> None:
    typer.echo("rollback: bootstrap implementation pending")
```

```python
# src/amanda_agent/__main__.py
from .cli import app

if __name__ == "__main__":
    app()
```

- [ ] **Step 4: Ensure Python 3.12 x64**

```powershell
py -3.12 --version
```

If absent:

```powershell
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
```

- [ ] **Step 5: Create venv and install**

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

- [ ] **Step 6: Verify test RED→GREEN**

```powershell
.\.venv\Scripts\python.exe -m pytest tests/unit/test_cli.py -v
```

Expected: PASS after implementation.

- [ ] **Step 7: Commit**

```powershell
git add pyproject.toml src tests
git commit -m "feat: add Amanda agent CLI foundation"
```

---

### Task 2: Canonical paths

**Files:**
- Create: `src/amanda_agent/paths.py`
- Test: `tests/unit/test_paths.py`

**Interfaces:** `ProjectPaths.from_root(Path) -> ProjectPaths`

- [ ] Write test asserting `state`, `logs`, `bim`, `PROJECT_STATE.yaml`, and snapshots derive from root.
- [ ] Implement:

```python
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class ProjectPaths:
    root: Path
    state: Path
    logs: Path
    bim: Path
    project_state: Path
    snapshots: Path

    @classmethod
    def from_root(cls, root: Path) -> "ProjectPaths":
        root = root.resolve()
        return cls(
            root=root,
            state=root / "state",
            logs=root / "logs",
            bim=root / "bim",
            project_state=root / "PROJECT_STATE.yaml",
            snapshots=root / "state" / "snapshots",
        )
```

- [ ] Run `pytest tests/unit/test_paths.py -v`.
- [ ] Commit `feat: add canonical project paths`.

---

### Task 3: Project-state models

**Files:**
- Create: `src/amanda_agent/models/state.py`
- Test: `tests/unit/test_state_models.py`

**Interfaces:** `TaskStatus`, `PhaseGate`, `ProjectState`.

- [ ] Write failing default-state test.
- [ ] Implement:

```python
from enum import StrEnum
from pydantic import BaseModel, Field

class TaskStatus(StrEnum):
    PENDING = "PENDING"
    READY = "READY"
    RUNNING = "RUNNING"
    VERIFYING = "VERIFYING"
    PASS = "PASS"
    PASS_WITH_WARNINGS = "PASS_WITH_WARNINGS"
    DEGRADED = "DEGRADED"
    BLOCKED_BY_INPUT = "BLOCKED_BY_INPUT"
    BLOCKED_BY_TOOL = "BLOCKED_BY_TOOL"
    FAILED_ROLLED_BACK = "FAILED_ROLLED_BACK"
    CRITICAL_FAILURE = "CRITICAL_FAILURE"

class PhaseGate(StrEnum):
    GO = "GO"
    GO_WITH_LIMITATIONS = "GO_WITH_LIMITATIONS"
    NO_GO = "NO_GO"

class ProjectState(BaseModel):
    project: str = "Amanda TFG BIM Agent"
    phase_id: str = "PHASE_01"
    phase_name: str = "foundation-environment-state"
    phase_status: TaskStatus = TaskStatus.PENDING
    last_completed_task: str | None = None
    next_task: str = "ENV-001"
    selected_design: str | None = None
    revit_stage: str = "R00"
    current_checkpoint: str | None = None
    blockers: list[str] = Field(default_factory=list)
    last_verified_commit: str | None = None
```

- [ ] Test JSON/YAML-safe model dump.
- [ ] Commit.

---

### Task 4: Atomic YAML state store

**Files:**
- Create: `src/amanda_agent/state/store.py`
- Test: `tests/unit/test_state_store.py`

**Interfaces:** `StateStore.load`, `StateStore.save`.

- [ ] Write round-trip test and assert no `.tmp` remains.
- [ ] Implement atomic replace:

```python
from pathlib import Path
import os, yaml
from amanda_agent.models.state import ProjectState

class StateStore:
    def __init__(self, path: Path):
        self.path = path

    def load(self) -> ProjectState:
        return ProjectState.model_validate(yaml.safe_load(self.path.read_text(encoding="utf-8")))

    def save(self, state: ProjectState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(yaml.safe_dump(state.model_dump(mode="json"), sort_keys=False), encoding="utf-8")
        os.replace(temp, self.path)
```

- [ ] Run tests.
- [ ] Commit.

---

### Task 5: Single-writer lock

**Files:**
- Create: `src/amanda_agent/state/locks.py`
- Test: `tests/unit/test_writer_lock.py`

**Interfaces:** `WriterLock.acquire(owner)`, `release`, `inspect`.

- [ ] Test two writers cannot acquire same lease.
- [ ] Implement exclusive file creation with owner/PID/host/timestamp JSON.
- [ ] Test release and stale lock inspection.
- [ ] Commit.

---

### Task 6: Detect actual Revit 2027 installation

**Files:**
- Create: `bootstrap/get-revit-metadata.ps1`
- Create: `src/amanda_agent/bootstrap/revit.py`
- Test: `tests/bootstrap/test_revit_detection.py`

**Interfaces:** returns executable, RevitAPI.dll, install path, product/file version.

- [ ] Write fake-filesystem test for `Autodesk/Revit 2027/RevitAPI.dll`.
- [ ] Create runtime script:

```powershell
$root = Join-Path $env:ProgramFiles "Autodesk"
$result = Get-ChildItem $root -Directory -Filter "Revit 20*" -ErrorAction SilentlyContinue | ForEach-Object {
  $exe = Join-Path $_.FullName "Revit.exe"
  $api = Join-Path $_.FullName "RevitAPI.dll"
  if ((Test-Path $exe) -and (Test-Path $api)) {
    $v = (Get-Item $exe).VersionInfo
    [pscustomobject]@{
      productName = $v.ProductName
      productVersion = $v.ProductVersion
      fileVersion = $v.FileVersion
      installPath = $_.FullName
      executablePath = $exe
      apiPath = $api
    }
  }
}
$result | ConvertTo-Json -Depth 4
```

- [ ] Run it on the live machine.
- [ ] Gate `NO_GO` if no Revit 2027 install is returned.
- [ ] Store exact build in environment report.
- [ ] Commit.

---

### Task 7: Probe Codex/Git/PowerShell/Python/.NET

**Files:**
- Create: `src/amanda_agent/bootstrap/environment.py`
- Test: `tests/bootstrap/test_environment_detection.py`

- [ ] Add parser test for `dotnet --list-sdks`.
- [ ] Probe:

```powershell
git --version
codex --version
$PSVersionTable.PSVersion.ToString()
py -3.12 --version
dotnet --list-sdks
```

- [ ] Ensure exact SDK `10.0.400` exists for Horizun source build.
- [ ] If WinGet lists exact 10.0.400:

```powershell
winget show Microsoft.DotNet.SDK.10 --versions
winget install -e --id Microsoft.DotNet.SDK.10 --version 10.0.400 --accept-package-agreements --accept-source-agreements
```

- [ ] If WinGet does not list it, install project-local from Microsoft's official install script:

```powershell
New-Item -ItemType Directory -Force ".tools\dotnet" | Out-Null
Invoke-WebRequest https://dot.net/v1/dotnet-install.ps1 -OutFile ".tools\dotnet-install.ps1"
powershell -ExecutionPolicy Bypass -File ".tools\dotnet-install.ps1" -Version 10.0.400 -InstallDir ".tools\dotnet"
& ".\.tools\dotnet\dotnet.exe" --version
```

Expected: `10.0.400`.

- [ ] Commit code, not local SDK binaries.

---

### Task 8: Snapshot Codex config and Revit add-in inventory

**Files:**
- Create: `src/amanda_agent/bootstrap/snapshots.py`
- Test: `tests/unit/test_snapshots.py`

- [ ] Write redaction test for keys containing TOKEN/SECRET/PASSWORD/API_KEY/AUTHORIZATION.
- [ ] Implement redaction.
- [ ] Snapshot current config before provider installation:

```powershell
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Dest = "state\snapshots\$Stamp"
New-Item -ItemType Directory -Force $Dest | Out-Null
if (Test-Path "$env:USERPROFILE\.codex\config.toml") {
  Copy-Item "$env:USERPROFILE\.codex\config.toml" "$Dest\codex-config.toml"
}
Get-ChildItem "C:\ProgramData\Autodesk\Revit\Addins\2027" -Recurse -ErrorAction SilentlyContinue |
  Select-Object FullName,Length,LastWriteTime |
  ConvertTo-Json -Depth 5 |
  Set-Content "$Dest\revit-addins-2027.json"
```

- [ ] Redact copied text before any Git staging.
- [ ] Commit only code/metadata safe for Git.

---

### Task 9: Structured JSONL logger

**Files:**
- Create: `src/amanda_agent/logging.py`
- Test: `tests/unit/test_logging.py`

- [ ] Test one record has timestamp/task/operation/provider/status.
- [ ] Implement append-only JSONL writer.
- [ ] Ensure redaction occurs before raw exception payloads are persisted.
- [ ] Commit.

---

### Task 10: `doctor`

**Files:**
- Create: `src/amanda_agent/commands/doctor.py`
- Modify: `src/amanda_agent/cli.py`
- Test: `tests/unit/test_doctor.py`

**Interfaces:** writes `state/environment-report.json`, returns nonzero on critical failure.

- [ ] Test missing Revit 2027 is critical.
- [ ] Test missing .NET 10.0.400 is critical before Plan 02.
- [ ] Test missing Codex is critical.
- [ ] Wire probes into report.
- [ ] Run `python -m amanda_agent doctor` on live PC.
- [ ] Commit.

---

### Task 11: `status`, `resume`, `rollback`

**Files:**
- Create command modules and tests.

- [ ] `status` is read-only and prints phase, next task, blocker count, writer lease, Revit stage.
- [ ] `resume` refuses when a blocker starts with `BLOCKING:`.
- [ ] `rollback` validates source checkpoint hash and copies it to a **new** working filename.
- [ ] `rollback` rejects target filenames containing `golden`, `master`, `source` case-insensitively.
- [ ] Test all four conditions.
- [ ] Commit.

---

### Task 12: Initialize durable state files

**Files:**
- Create: `PROJECT_STATE.yaml`
- Create: `state/bim-environment.lock.yaml`
- Create: `state/blockers.yaml`
- Create: `state/tool-health.yaml`

- [ ] Serialize default `ProjectState` with the real code.
- [ ] Record actual Revit build, Python, Codex, Git, PowerShell, .NET SDKs.
- [ ] Initialize topography as `UNKNOWN_UNTIL_INGEST`, not as a numeric value.
- [ ] Commit state baselines.

---

---

### Task 13: Add the idempotent `bootstrap` command

**Files:**
- Create: `src/amanda_agent/commands/bootstrap.py`
- Modify: `src/amanda_agent/cli.py`
- Test: `tests/unit/test_bootstrap_cli.py`

**Interfaces:** `amanda-agent bootstrap` performs only foundation/environment setup that is safe to repeat. Provider installation belongs to Plan 02.

- [ ] **Step 1: Write a test that `bootstrap` is idempotent against a temporary project root**
- [ ] **Step 2: Implement orchestration of directory creation, environment probing, safe snapshots, default state initialization, and environment-report write**
- [ ] **Step 3: Make a second invocation preserve existing state values and create no duplicate logical configuration**
- [ ] **Step 4: Run:**

```powershell
.\.venv\Scripts\python.exe -m pytest tests/unit/test_bootstrap_cli.py -v
.\.venv\Scripts\python.exe -m amanda_agent bootstrap
```

Expected: exit 0 when Plan 01 prerequisites are green; no Revit provider is installed.

- [ ] **Step 5: Commit**

```powershell
git add src/amanda_agent/commands/bootstrap.py src/amanda_agent/cli.py tests/unit/test_bootstrap_cli.py
git commit -m "feat: add idempotent environment bootstrap command"
```

## Phase 01 Verification Gate

Run:

```powershell
.\.venv\Scripts\python.exe -m pytest tests/unit tests/bootstrap -q
.\.venv\Scripts\python.exe -m amanda_agent doctor
.\.venv\Scripts\python.exe -m amanda_agent status
git status --short
```

### GO
- tests PASS;
- exact Revit 2027 build recorded;
- Codex detected;
- .NET 10.0.400 available;
- snapshots created;
- state files valid;
- no stale writer lease;
- Git clean.

### NO_GO
Any critical item above fails. Plan 02 must not begin.

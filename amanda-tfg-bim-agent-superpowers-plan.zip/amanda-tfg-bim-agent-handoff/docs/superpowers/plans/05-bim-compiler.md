# BIM Compiler and Revit Desired-State Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use `superpowers:subagent-driven-development` or `superpowers:executing-plans`; TDD for compiler/policy code; systematic debugging for provider/Revit failures; verification-before-completion before stage promotion.

**Goal:** Compile a solution explicitly marked `APPROVED_FOR_BIM` into staged Revit 2027 checkpoints using the verified Capability Registry, with desired-state diffs, stable logical IDs, unit safety, provenance, checkpoints, and rollback.

**Architecture:** The Python compiler produces a read-only `BIM_PLAN.json`. Codex executes the plan through actual MCP tools selected from the Capability Registry. The compiler never decides architecture inside Revit; it reconciles desired state against current managed state and requests the smallest safe mutation set.

**Tech Stack:** Python 3.12, Revit 2027, verified Horizun/RevitCortex MCP capabilities, custom C# fallback, Shapely, IfcOpenShell.

**Spec:** `docs/superpowers/specs/2026-09-11-amanda-tfg-bim-agent-design.md`

## Global Constraints

- Detailed production compile requires `APPROVED_FOR_BIM`.
- Safety Sentinel must pass before every production write.
- One writer lock.
- Every write re-read and verified.
- Every stage produces a checkpoint/hash before the next stage.
- Logical IDs survive Revit ElementId replacement.
- Units convert through one library.
- Missing verified topography forbids final grading/altimetric claims.
- Destructive diff threshold blocks mass deletion/replacement.

## File Structure

```text
src/amanda_agent/bim/
├── models.py
├── units.py
├── provenance.py
├── desired_state.py
├── current_state.py
├── diff.py
├── plan.py
├── safety.py
├── checkpoints.py
├── verification.py
└── stages/
    ├── project.py
    ├── site.py
    ├── levels.py
    ├── massing.py
    ├── shell.py
    ├── layout.py
    ├── openings.py
    ├── rooms.py
    ├── accessibility.py
    ├── furniture.py
    ├── landscape.py
    ├── materials.py
    └── documentation.py
```

---

### Task 1: Revit unit conversion library

**Files:**
- Create: `src/amanda_agent/bim/units.py`
- Test: `tests/unit/test_revit_units.py`

**Interfaces:** `meters_to_feet`, `feet_to_meters`, `sqm_to_sqft`, `sqft_to_sqm`.

- [ ] Write round-trip tests for 1 m, 10 m, 1 m², 24 m².
- [ ] Implement exact 1 ft = 0.3048 m conversion.
- [ ] Keep all Design Engine data metric; convert only at Revit boundary.
- [ ] Commit.

---

### Task 2: BIM stage and desired-element models

**Files:**
- Create: `src/amanda_agent/bim/models.py`
- Create: `src/amanda_agent/bim/provenance.py`
- Test: `tests/unit/test_bim_models.py`

Stages:
`R00 EMPTY_SANDBOX`, `R01 PROJECT_INITIALIZED`, `R02 SITE`, `R03 LEVELS_AND_REFERENCES`, `R04 MASSING`, `R05 ARCHITECTURAL_SHELL`, `R06 INTERNAL_LAYOUT`, `R07 OPENINGS`, `R08 ROOMS`, `R09 ACCESSIBILITY`, `R10 FURNITURE`, `R11 LANDSCAPE`, `R12 MATERIALS`, `R13 DOCUMENTATION`, `R14 QA`, `R15 RELEASE_CANDIDATE`, `R16 GOLDEN`.

- [ ] `DesiredElement` requires logical_id, category, geometry/properties, requirement_id, design_option, generation_run.
- [ ] Test duplicate logical IDs rejected.
- [ ] Commit.

---

### Task 3: Safety Sentinel

**Files:**
- Create: `src/amanda_agent/bim/safety.py`
- Test: `tests/unit/test_bim_safety.py`

**Interfaces:** `assert_writable_target(Path)`.

- [ ] Test path containing `GOLDEN` rejected.
- [ ] Test `MASTER` rejected.
- [ ] Test `source` rejected.
- [ ] Test `revit/production/working/AMANDA_WORKING_001.rvt` accepted.
- [ ] Implement case-insensitive filename/path policy.
- [ ] Commit.

---

### Task 4: Checkpoint manager

**Files:**
- Create: `src/amanda_agent/bim/checkpoints.py`
- Test: `tests/unit/test_checkpoints.py`

**Interfaces:** create immutable stage copy + SHA256 manifest; verify hash before rollback.

- [ ] Test file copy hash equality.
- [ ] Test existing checkpoint path cannot be overwritten.
- [ ] Test GOLDEN cannot be used as writable checkpoint target.
- [ ] Implement.
- [ ] Commit.

---

### Task 5: Desired/current-state diff

**Files:**
- Create: `src/amanda_agent/bim/desired_state.py`
- Create: `src/amanda_agent/bim/current_state.py`
- Create: `src/amanda_agent/bim/diff.py`
- Test: `tests/unit/test_bim_diff.py`

Actions: `CREATE`, `UPDATE`, `REPLACE`, `NOOP`, `DELETE`.

- [ ] 17 correct + 1 missing desired room → one CREATE.
- [ ] Existing logical ID + equivalent geometry/properties → NOOP.
- [ ] Duplicate current logical ID → hard error.
- [ ] Unmanaged Revit elements are not deleted by default.
- [ ] Commit.

---

### Task 6: Destructive-change threshold

**Files:**
- Modify: `src/amanda_agent/bim/diff.py`
- Test: `tests/unit/test_destructive_threshold.py`

- [ ] Baseline threshold 10% of **managed** elements for DELETE/REPLACE.
- [ ] 11 destructive operations / 100 managed → block `HIGH_RISK_PLAN`.
- [ ] 5 / 100 may proceed only with a pre-operation checkpoint.
- [ ] Threshold config lives in versioned YAML.
- [ ] Commit.

---

### Task 7: BIM plan generator

**Files:**
- Create: `src/amanda_agent/bim/plan.py`
- Test: `tests/unit/test_bim_plan.py`

Every operation contains:
- task_id;
- logical_id;
- action;
- semantic capability;
- desired payload;
- verification rules;
- preferred provider + verified fallbacks from registry.

- [ ] Stable operation ordering.
- [ ] Reject capability chain if all providers `UNTESTED/FAIL`.
- [ ] Plan generation is read-only.
- [ ] Write human summary `BIM_PLAN.md` alongside JSON.
- [ ] Commit.

---

### Task 8: Write-read-verify result model

**Files:**
- Create: `src/amanda_agent/bim/verification.py`
- Test: `tests/unit/test_verification.py`

Verification layers:
1. existence;
2. properties;
3. geometry;
4. persistence when required.

- [ ] Tool says success but query misses element → FAIL.
- [ ] Element exists but geometry exceeds tolerance → FAIL.
- [ ] Correct element → PASS.
- [ ] Commit.

---

### Task 9: Project initialization stage R01

**Files:**
- Create: `src/amanda_agent/bim/stages/project.py`
- Test: `tests/unit/test_stage_project.py`

- [ ] Preflight requires approved solution, healthy registry, correct Revit build.
- [ ] Template order: Amanda template copy if supplied and tested; else installed architectural template discovered on machine.
- [ ] Desired project metadata/naming is deterministic.
- [ ] Lab-execute R01 and save/reopen.
- [ ] Checkpoint `R01_PROJECT_INITIALIZED`.

---

### Task 10: Site stage R02

**Files:**
- Create: `src/amanda_agent/bim/stages/site.py`
- Test: `tests/unit/test_stage_site.py`

Modes:
- `PLANAR_PLACEHOLDER`: site boundary/reference only; no invented Z.
- `VERIFIED_TOPOGRAPHY`: may request Toposolid/grading capability.

- [ ] Test missing topography yields no Z points.
- [ ] Test verified point set creates desired Toposolid operation only if capability registry has a PASS provider.
- [ ] Run synthetic site through lab preferred provider.
- [ ] Verify extents/elevations and save/reopen.
- [ ] Checkpoint.

---

### Task 11: Levels/references R03

**Files:** `src/amanda_agent/bim/stages/levels.py`, tests.

- [ ] Generate only levels required by selected solution/topography.
- [ ] Do not invent structural grid/system.
- [ ] Verify name/elevation after write.
- [ ] Checkpoint.

---

### Task 12: Massing R04

**Files:** `src/amanda_agent/bim/stages/massing.py`, tests.

- [ ] Convert approved block polygons to simplified Revit masses/surrogate geometry supported by verified provider.
- [ ] Compare centroid, area, dimensions, rotation, separation, site containment against design JSON.
- [ ] Export 3D preview if verified capability exists.
- [ ] Reject any geometry mismatch beyond tolerances.
- [ ] Checkpoint.

---

### Task 13: Architectural shell R05

**Files:** `src/amanda_agent/bim/stages/shell.py`, tests.

- [ ] Exterior walls from approved polygons.
- [ ] Floors from closed loops.
- [ ] Simple approved roof representation.
- [ ] Controlled type catalog only (`EXT_WALL_01`, `INT_WALL_01`, etc.); no uncontrolled type proliferation.
- [ ] Query duplicate/off-axis/unjoined warnings.
- [ ] Save/reopen and checkpoint.

---

### Task 14: Internal layout R06

**Files:** `src/amanda_agent/bim/stages/layout.py`, tests.

- [ ] Convert room polygons to internal walls/boundaries.
- [ ] Preserve logical IDs independent of ElementId.
- [ ] Measure actual modeled room polygons.
- [ ] Accept configured area range; do not deform walls to chase exact decimals.
- [ ] Checkpoint.

---

### Task 15: Openings R07

**Files:** `src/amanda_agent/bim/stages/openings.py`, `project/bim/family-registry.yaml`, tests.

Family priority:
1. appropriate existing project family;
2. validated installed Autodesk content;
3. controlled project family;
4. generated/adapted family through verified provider/custom API;
5. project placeholder.

- [ ] Never auto-download arbitrary internet families.
- [ ] Verify door/window host, dimensions, intended connectivity, collision.
- [ ] Checkpoint.

---

### Task 16: Rooms R08

**Files:** `src/amanda_agent/bim/stages/rooms.py`, tests.

- [ ] Create/associate one room object per canonical room logical ID.
- [ ] Store name, number, sector, target area, privacy and source/requirement ID in managed metadata where safe.
- [ ] Query all rooms.
- [ ] Reject unplaced/not-enclosed/redundant managed rooms.
- [ ] Reconcile quantities/areas.
- [ ] Checkpoint.

---

### Task 17: Accessibility R09

**Files:** `src/amanda_agent/bim/stages/accessibility.py`, tests.

- [ ] Numeric rules loaded only from VERIFIED regulation registry.
- [ ] Build accessible route graph from entrance through required accessible spaces.
- [ ] If normative numeric data absent, output `BLOCKED_BY_INPUT` for those checks, never false PASS.
- [ ] Verify geometric checks supported by available source data.
- [ ] Checkpoint only for completed supported scope.

---

### Task 18: Furniture R10

**Files:** `src/amanda_agent/bim/stages/furniture.py`, controlled catalog, tests.

- [ ] Functional placeholders only after room geometry/clearances stabilize.
- [ ] Bedroom, psychology/technical, dining, office, child-area fixture sets are explicit.
- [ ] Use furnishings for spatial QA, not decorative randomization.
- [ ] Checkpoint.

---

### Task 19: Landscape R11

**Files:** `src/amanda_agent/bim/stages/landscape.py`, tests.

- [ ] Every programmed external space keeps logical ID and target area.
- [ ] Verify intended privacy/adjacency.
- [ ] Vegetation starts as controlled placeholders.
- [ ] West/privacy vegetation strategy can be represented only when it is part of approved option, not injected ad hoc.
- [ ] Checkpoint.

---

### Task 20: Materials R12

**Files:** `src/amanda_agent/bim/stages/materials.py`, `project/bim/material-catalog.yaml`, tests.

- [ ] Controlled catalog.
- [ ] No duplicate material names/types per run.
- [ ] Explicit material choices, traceable to selected design intent.
- [ ] Checkpoint.

---

### Task 21: Documentation R13

**Files:** `src/amanda_agent/bim/stages/documentation.py`, view/sheet registries, tests.

- [ ] Deterministic plan/site/roof view list.
- [ ] Sections selected for architectural relationships (courtyard/residential/transitions/access), not arbitrary count.
- [ ] Elevations.
- [ ] Room/door/window schedules and area summary.
- [ ] Sheet registry and view placement plan.
- [ ] Dimension/tag plan.
- [ ] Execute lab documentation build through verified capabilities.
- [ ] Export previews for Plan 06 QA.
- [ ] Checkpoint.

---

### Task 22: BIM CLI

**Files:**
- Create: `src/amanda_agent/commands/bim.py`
- Modify: `src/amanda_agent/cli.py`
- Test: `tests/unit/test_bim_cli.py`

Commands:
- `amanda-agent bim plan --solution PATH`
- `amanda-agent bim verify-plan PATH`
- `amanda-agent bim status`

- [ ] Unapproved solution rejected.
- [ ] GOLDEN/source target rejected.
- [ ] `plan` never mutates Revit.
- [ ] Plan contains only tested provider chains.
- [ ] Commit.

---

### Task 23: Synthetic end-to-end BIM compile

**Fixture:** regression courtyard solution, not Amanda production.

- [ ] Acquire writer lease.
- [ ] Copy lab baseline to new working RVT.
- [ ] Compile R01→R13 in order.
- [ ] Stage checkpoint after each PASS.
- [ ] Force one preferred-provider failure on a noncritical synthetic operation and prove registry fallback is used.
- [ ] Save/close/restart/reopen at R13.
- [ ] Re-query managed logical IDs.
- [ ] Run model/program QA subset.
- [ ] Release writer lease.
- [ ] Write `tool-lab/reports/bim-compiler-e2e.md` with provider choices/fallbacks/warnings/durations.

---

## Phase 05 Verification Gate

### GO
Synthetic approved solution reaches R13, survives restart/reopen, preserves IDs/state, and exercises verified fallback without duplicate corruption.

### GO_WITH_LIMITATIONS
A nonessential family/documentation/site feature is degraded but has a tested safe alternative and is represented in the registry.

### NO_GO
Safety Sentinel can be bypassed, unmanaged elements are destroyed, duplicate managed elements appear, or restart/reopen diverges from desired state.

# Project Intelligence and Source Ingestion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use `superpowers:subagent-driven-development` or `superpowers:executing-plans`; TDD for parser/schema code; systematic debugging for reconciliation failures.

**Goal:** Convert Amanda's TFG, program of needs, site material, and verified normative/source files into canonical structured project data with immutable provenance and an explicit missing-data registry.

**Architecture:** Source files are immutable. Extraction produces three separate classes: `SOURCE_FACT`, `DERIVED_CONSTRAINT`, and `DESIGN_HYPOTHESIS`. Canonical JSON/YAML is schema-validated and becomes the only input consumed by the Design Engine.

**Tech Stack:** Python 3.12, Pydantic, PyYAML, local PDF parser, Shapely/GeoJSON.

**Spec:** `docs/superpowers/specs/2026-09-11-amanda-tfg-bim-agent-design.md`

## Global Constraints

- Preserve original source bytes and SHA-256.
- Never silently “correct” Amanda's source values.
- Every `SOURCE_FACT` has a source reference.
- Missing topography remains missing.
- Numeric normative rules enter hard constraints only from a verified source/version.

## File Structure

```text
src/amanda_agent/
├── ingest/
│   ├── manifest.py
│   ├── provenance.py
│   ├── pdf.py
│   └── pipeline.py
├── requirements/
│   ├── models.py
│   ├── relations.py
│   ├── regulations.py
│   └── validators.py
└── site/
    ├── models.py
    ├── geometry.py
    └── transform.py

project/
├── requirements/
├── site/
├── regulations/
├── references/
└── provenance/

docs/source/
```

---

### Task 1: Source manifest and hashing

**Files:**
- Create: `src/amanda_agent/ingest/manifest.py`
- Test: `tests/unit/test_source_manifest.py`

**Interfaces:** `sha256_file(Path) -> str`, `SourceDocument`.

- [ ] Write SHA-256 fixture test using `abc` known digest.
- [ ] Implement streaming file hash (1 MiB chunks; no full-file load required).
- [ ] Define `SourceDocument` fields: source_id, filename, sha256, mime_type, ingested_at, immutable_path.
- [ ] Test round-trip.
- [ ] Commit.

---

### Task 2: Provenance model

**Files:**
- Create: `src/amanda_agent/ingest/provenance.py`
- Test: `tests/unit/test_provenance.py`

**Interfaces:**

```python
class FactClass(StrEnum):
    SOURCE_FACT = "SOURCE_FACT"
    DERIVED_CONSTRAINT = "DERIVED_CONSTRAINT"
    DESIGN_HYPOTHESIS = "DESIGN_HYPOTHESIS"
```

Each `SourceReference` includes source ID, page/line locator when available, extraction method, confidence, note.

- [ ] Test `SOURCE_FACT` without source ID is rejected.
- [ ] Test a hypothesis cannot claim fact class.
- [ ] Implement.
- [ ] Commit.

---

### Task 3: Immutable ingest command

**Files:**
- Create: `src/amanda_agent/commands/ingest.py`
- Modify: `src/amanda_agent/cli.py`
- Test: `tests/unit/test_ingest_command.py`

**Interfaces:** `amanda-agent ingest PATH...`

- [ ] Test source copied byte-for-byte into `docs/source/`.
- [ ] Test same content hash is recognized and not duplicated unnecessarily.
- [ ] Test a different file cannot overwrite an existing immutable source path.
- [ ] Generate/update `project/provenance/source-manifest.yaml` atomically.
- [ ] Commit.

---

### Task 4: Ingest the two known Amanda documents when available to Codex

**Expected sources:** Amanda TFG PDF and program-of-needs PDF.

- [ ] Search the explicitly provided input folder/path, not the entire user's home drive.
- [ ] If either source is absent, set production blocker `BLOCKED_BY_INPUT:SOURCE_DOCUMENTS`, but keep synthetic development usable.
- [ ] When present, assign stable IDs `SRC-TFG-001`, `SRC-PROGRAM-001` for this source version.
- [ ] Compute hashes.
- [ ] Verify copied bytes match hashes.
- [ ] Keep PDFs private/local; commit them only if repository policy explicitly allows source documents. Manifests can be committed independently.

---

### Task 5: PDF text extraction adapter

**Files:**
- Create: `src/amanda_agent/ingest/pdf.py`
- Test: `tests/unit/test_pdf_adapter.py`

- [ ] Add a local parser dependency only after a small compatibility test; prefer PyMuPDF or pypdf based on actual extraction quality.
- [ ] Create fixture PDF with two pages and known text.
- [ ] Test page-number-preserving extraction.
- [ ] Store extracted text under `project/provenance/extracted/` with source hash.
- [ ] Never treat OCR output as authoritative when selectable text exists.
- [ ] Commit parser choice/version to environment lock.

---

### Task 6: Program requirement schema

**Files:**
- Create: `src/amanda_agent/requirements/models.py`
- Test: `tests/unit/test_requirement_models.py`

**Interfaces:** `SpaceRequirement`, `SectorRequirement`, `ProgramRequirementSet`.

- [ ] Write tests rejecting zero/negative area and quantity.
- [ ] Implement:

```python
from pydantic import BaseModel, Field, model_validator

class SpaceRequirement(BaseModel):
    logical_id: str
    name: str
    sector: str
    quantity: int = Field(ge=1)
    target_area_m2: float = Field(gt=0)
    min_area_m2: float | None = Field(default=None, gt=0)
    max_area_m2: float | None = Field(default=None, gt=0)
    privacy_level: int = Field(ge=0, le=5)
    accessible: bool = False
    source_refs: list[str]

    @model_validator(mode="after")
    def valid_range(self):
        if self.min_area_m2 is not None and self.target_area_m2 < self.min_area_m2:
            raise ValueError("target below minimum")
        if self.max_area_m2 is not None and self.target_area_m2 > self.max_area_m2:
            raise ValueError("target above maximum")
        return self
```

- [ ] Test and commit.

---

### Task 7: Compile the program of needs into canonical JSON

**Files:**
- Create at runtime: `project/requirements/program.json`
- Create: `project/requirements/program-summary.md`
- Test: `tests/project/test_amanda_program.py`

- [ ] Extract every program line item exactly from source.
- [ ] Assign stable logical IDs by sector/space instance.
- [ ] Record source quantity/target-area facts.
- [ ] Record source capacity reference (up to 20 simultaneous residents) as a fact.
- [ ] Reconcile source subtotals and overall internal/external totals.
- [ ] Add tests for known source totals and presence of accessible bedroom/bathroom requirements.
- [ ] Generate markdown summary from canonical JSON, never the reverse.
- [ ] Commit canonical JSON and tests.

---

### Task 8: Relations schema

**Files:**
- Create: `src/amanda_agent/requirements/relations.py`
- Test: `tests/unit/test_relations.py`

Relation enum:
- `MUST_ADJOIN`
- `SHOULD_ADJOIN`
- `SHOULD_BE_NEAR`
- `CAN_BE_NEAR`
- `NEUTRAL`
- `SHOULD_BE_SEPARATED`
- `MUST_BE_SEPARATED`

- [ ] Test self-relations rejected unless explicitly whitelisted for group relation.
- [ ] Add weight and optional max/preferred distance.
- [ ] Add flow-network enum: resident, child, staff, visitor, service, emergency.
- [ ] Commit.

---

### Task 9: Compile source-backed principles separately from design hypotheses

**Files:**
- Create: `project/requirements/source-principles.yaml`
- Create: `project/requirements/design-hypotheses.yaml`
- Test: `tests/project/test_fact_separation.py`

- [ ] Extract only TFG-supported principles into source-principles, including the stated shelter/transition/city logic, block/garden parti, privacy/security concepts, and stated climate orientation findings.
- [ ] Put inferred room adjacency proposals into design-hypotheses.
- [ ] Every source principle gets source refs.
- [ ] Validator forbids a `DESIGN_HYPOTHESIS` object from appearing in source-principles.
- [ ] Commit.

---

### Task 10: Canonical site schema

**Files:**
- Create: `src/amanda_agent/site/models.py`
- Test: `tests/unit/test_site_models.py`

Fields:
- boundary polygon;
- design coordinate origin;
- true north;
- frontages/roads;
- candidate access points;
- buildable area if verified;
- setbacks if verified;
- topography state;
- provenance.

Topography enum:
- `MISSING`
- `PLANAR_PLACEHOLDER`
- `VERIFIED_TOPOGRAPHY`

- [ ] Test invalid self-intersecting boundary is rejected by Shapely.
- [ ] Test `MISSING` cannot carry invented elevation points.
- [ ] Commit.

---

### Task 11: Compile known site facts and missing-data registry

**Files:**
- Create: `project/site/site.json`
- Create: `project/site/missing-data.yaml`

- [ ] Record source-backed total site area/frontages.
- [ ] Record the four named street/frontage relationships as facts.
- [ ] Record true north/orientation only from verified source drawing/data.
- [ ] If no verified survey/topographic file is supplied, set `topography = MISSING`.
- [ ] Add blocker:

```yaml
id: SITE_TOPOGRAPHY
state: MISSING
blocks:
  - final_grading
  - final_altimetric_accessibility_validation
allows:
  - 2d_macrozoning
  - schematic_massing_on_planar_reference
```

- [ ] Commit.

---

### Task 12: Regulation source registry

**Files:**
- Create: `src/amanda_agent/requirements/regulations.py`
- Create: `project/regulations/registry.yaml`
- Test: `tests/unit/test_regulation_registry.py`

Statuses: `IDENTIFIED`, `SOURCE_ACQUIRED`, `VERIFIED`, `SUPERSEDED`.

- [ ] Seed regulation names identified by Amanda's TFG without copying remembered numerical rules.
- [ ] Require source file/version/page/section before a numeric rule can become `DERIVED_CONSTRAINT`.
- [ ] Test an unverified numeric rule cannot be compiled as hard constraint.
- [ ] Commit.

---

### Task 13: Provenance integrity suite

**Files:** `tests/project/test_provenance_integrity.py`

- [ ] Every source fact has source ref.
- [ ] Every requirement logical ID unique.
- [ ] No unresolved numeric source placeholder silently became a number.
- [ ] No hypothesis exists in source-fact files.
- [ ] Source file hashes still match immutable copies.
- [ ] Program subtotal/global reconciliation passes.
- [ ] Commit.

---

### Task 14: One-command validation report

**Files:**
- Modify: `src/amanda_agent/commands/ingest.py`
- Runtime: `docs/reports/ingest-report.md`

- [ ] `amanda-agent ingest --validate-only` validates source hashes, canonical schemas, provenance, program totals, site status, regulation registry.
- [ ] Expected missing topography yields `GO_WITH_LIMITATIONS`, not corruption.
- [ ] Malformed canonical data yields nonzero exit.
- [ ] Report exact blocker IDs.
- [ ] Commit.

---

## Phase 03 Verification Gate

```powershell
.\.venv\Scripts\python.exe -m pytest tests/unit tests/project -q
.\.venv\Scripts\python.exe -m amanda_agent ingest --validate-only
```

### GO
Canonical program/site/provenance valid and sufficient for intended design stage.

### GO_WITH_LIMITATIONS
Survey/topography or a normative source is missing, but schematic design remains valid within declared limits.

### NO_GO
Program/site source cannot be reconciled or source provenance is unreliable.

# Planos Amanda revisados em 2026-09-15

Leia START_HERE_FOR_CODEX.md. Os quatro Markdown da raiz são canônicos; docs/superpowers/plans contém cópias por fase geradas do COMBINED. Este pacote contém documentação e evidências estáticas, não implementação nem fontes acadêmicas. O ZIP original foi preservado no workspace. Revit/runtime: NOT_RUN.
